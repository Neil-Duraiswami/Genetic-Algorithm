package Genetic_Algorithm;

import java.util.Random;

public class GeneticAlgorithm {
    private int populationSize;
    private double mutationRate;
    private double crossoverRate;
    private int elitismCount;
    private Random random;

    public GeneticAlgorithm(int populationSize, double mutationRate, double crossoverRate, int elitismCount) {
        this.populationSize = populationSize;
        this.mutationRate = mutationRate;
        this.crossoverRate = crossoverRate;
        this.elitismCount = elitismCount;
        this.random = new Random();
    }

    public Population evolvePopulation(Population pop) {
        Population newPopulation = new Population(pop.size(), pop.getIndividual(0).getGeneLength());

        // Keep our best individual if elitism is enabled
        if (elitismCount > 0) {
            newPopulation.saveIndividual(0, pop.getFittest());
        }

        // Crossover population
        for (int i = elitismCount; i < populationSize; i++) {
            // Select parents
            Individual parent1 = selectTournament(pop);
            Individual parent2 = selectTournament(pop);
            // Crossover parents
            Individual child = crossover(parent1, parent2);
            // Add child to new population
            newPopulation.saveIndividual(i, child);
        }

        // Mutate the new population
        for (int i = elitismCount; i < populationSize; i++) {
            mutate(newPopulation.getIndividual(i));
        }

        return newPopulation;
    }

    private Individual selectTournament(Population pop) {
        Population tournament = new Population(elitismCount, pop.getIndividual(0).getGeneLength());
        for (int i = 0; i < elitismCount; i++) {
            int randomId = random.nextInt(populationSize);
            tournament.saveIndividual(i, pop.getIndividual(randomId));
        }
        return tournament.getFittest();
    }

    private Individual crossover(Individual parent1, Individual parent2) {
        Individual child = new Individual(parent1.getGeneLength());
        for (int i = 0; i < parent1.getGeneLength(); i++) {
            // Crossover at a uniform rate
            if (random.nextDouble() <= crossoverRate) {
                child.setGene(i, parent1.getGene(i));
            } else {
                child.setGene(i, parent2.getGene(i));
            }
        }
        return child;
    }

    private void mutate(Individual indiv) {
        // Loop through genes
        for (int i = 0; i < indiv.getGeneLength(); i++) {
            if (random.nextDouble() <= mutationRate) {
                // Create random gene within bounds using the constants from the Individual class
                double gene = Individual.MIN_GENE + random.nextDouble() * (Individual.MAX_GENE - Individual.MIN_GENE);
                indiv.setGene(i, gene);
            }
        }
}
}