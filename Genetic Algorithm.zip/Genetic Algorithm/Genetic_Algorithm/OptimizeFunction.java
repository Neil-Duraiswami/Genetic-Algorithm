package Genetic_Algorithm;

public class OptimizeFunction {
    public static void main(String[] args) {
        int geneLength = 10; // Number of dimensions for the Rastrigin function
        int populationSize = 100;
        double mutationRate = 0.01;
        double crossoverRate = 0.9;
        int elitismCount = 1;
        int maxGenerations = 1000;

        GeneticAlgorithm ga = new GeneticAlgorithm(populationSize, mutationRate, crossoverRate, elitismCount);

        // Initialize population
        Population population = new Population(populationSize, geneLength);


        int generationCount = 0;           // Evolve population for a certain number of generations
        while (generationCount < maxGenerations) {
            population = ga.evolvePopulation(population);
            generationCount++;

            
            System.out.println("Generation " + generationCount + ": Best Fitness = " + population.getFittest().getFitness()); //print the fitness of the best individual at each generation
        }

        // Output the best solution found
        Individual bestIndividual = population.getFittest();
        System.out.println("Finished");
        System.out.println("Best solution found:");
        System.out.print("Genes: ");
        for (double gene : bestIndividual.getGenes()) {
            System.out.print(gene + " ");
        }
        System.out.println("\nFitness: " + bestIndividual.getFitness());
    }
}

