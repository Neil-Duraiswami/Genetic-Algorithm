package Genetic_Algorithm;

public class Individual {
	public static final double MIN_GENE = -5.12;
    public static final double MAX_GENE = 5.12;
    private double[] genes;
    private double fitness = Double.MAX_VALUE;

    public Individual(int geneLength) {
        genes = new double[geneLength];
        // Random initialization of genes within the range [-5.12, 5.12]
        for (int i = 0; i < genes.length; i++) {
            genes[i] = -5.12 + Math.random() * (5.12 - (-5.12));
        }
    }

    public double getFitness() {
        if (fitness == Double.MAX_VALUE) {
            fitness = calculateFitness();
        }
        return fitness;
    }

    public double calculateFitness() {
        double sum = 0;
        for (int i = 0; i < genes.length; i++) {
            sum += (genes[i] * genes[i]) - (10 * Math.cos(2 * Math.PI * genes[i]));
        }
        return 10 * genes.length + sum;
    }

    public double getGene(int index) {
        return genes[index];
    }
    
    public double[] getGenes() {
        return genes;
    }
    public void setGene(int index, double value) {
        genes[index] = value;
        fitness = Double.MAX_VALUE;
    }

    public int getGeneLength() {
        return genes.length;
    }
}
